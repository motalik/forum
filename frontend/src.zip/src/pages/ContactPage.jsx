import React from 'react';


function LoginPage() {
  return (
    <div>
      
      few
    </div>
  );
}

export default LoginPage;
