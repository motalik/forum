import React from 'react';


function LoginPage() {
  return (
    <div>
      
      
    </div>
  );
}

export default LoginPage;
